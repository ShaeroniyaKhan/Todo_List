import firebase from 'firebase/compat/app';
import 'firebase/compat/auth';
import 'firebase/compat/firestore';

const firebaseConfig = {
    apiKey: "AIzaSyDDcbvMuQk25Ig_MgmY3zpHM9rV6Mdx6Ak",
    authDomain: "test-b8efb.firebaseapp.com",
    projectId: "test-b8efb",
    storageBucket: "test-b8efb.appspot.com",
    messagingSenderId: "386312844170",
    appId: "1:386312844170:web:37155f36a9c2c75bedce73",
    measurementId: "G-SV1F7HEMPY"
};

if(!firebase.apps.length) {
    firebase.initializeApp(firebaseConfig)
    
}

export {firebase};